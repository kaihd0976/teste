para dar start nesta porra 

1-npm i 
2-npm run dev