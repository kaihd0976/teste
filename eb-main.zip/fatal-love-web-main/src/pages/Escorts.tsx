import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious 
} from "@/components/ui/carousel";
import { Play, MapPin } from "lucide-react";

const filters = [
  "Online",
  "Com local",
  "Com áudio",
  "Mídia de comparação recente",
  "Até R$100",
  "Sexo anal",
  "Fotos com rosto",
  "Em expediente"
];

const categories = [
  { id: 1, name: "Mulheres", active: true },
  { id: 2, name: "Homens", active: false },
  { id: 3, name: "Trans", active: false },
];

const featuredProfiles = [
  { id: 1, name: "Lunna", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 2, name: "Bianca Tavares", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 3, name: "Nandinha", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 4, name: "Pocahontass", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 5, name: "VALENTINA A", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 6, name: "Camilla Barbie", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 7, name: "Laís Biancatti", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 8, name: "Lorena Lima", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 9, name: "Yumi Villar", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 10, name: "Loren", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
  { id: 11, name: "Bia Rocha", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP" },
];

const regularProfiles = [
  { id: 1, name: "Julia Silva", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP", hasReviews: true },
  { id: 2, name: "Amanda Costa", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP", hasReviews: true },
  { id: 3, name: "Carla Santos", image: "/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png", location: "São Paulo, SP", hasReviews: true },
];

const Escorts = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex flex-col gap-6">
          {/* Breadcrumb */}
          <nav className="text-sm text-gray-500">
            <ol className="flex items-center gap-2">
              <li><a href="/" className="hover:text-primary">lovable Model</a></li>
              <li>›</li>
              <li><a href="/escorts" className="hover:text-primary">Acompanhantes em São Paulo</a></li>
              <li>›</li>
              <li className="text-gray-700">Acompanhantes em São Paulo - SP</li>
            </ol>
          </nav>

          {/* Title */}
          <h1 className="text-2xl font-bold text-textDark">
            Acompanhantes mulheres<br />
            em São Paulo - SP
          </h1>

          {/* Featured Profiles Carousel */}
          <div className="relative -mx-4 px-4">
            <Carousel
              opts={{
                align: "start",
                loop: true,
                dragFree: true,
              }}
              className="w-full"
            >
              <CarouselContent className="-ml-1">
                {featuredProfiles.map((profile) => (
                  <CarouselItem key={profile.id} className="pl-1 md:basis-[68px] lg:basis-[68px] basis-[68px]">
                    <div className="relative group cursor-pointer">
                      <div className="relative rounded-full overflow-hidden aspect-square w-16 h-16 p-[3px] bg-gradient-to-tr from-[#FF1A1A] via-[#E2336B] to-[#FCAF45] transition-transform duration-300 transform group-hover:scale-105">
                        <div className="absolute inset-[-2px] bg-gradient-to-tr from-[#FF1A1A] via-[#E2336B] to-[#FCAF45] animate-gradient-xy rounded-full"></div>
                        <div className="relative rounded-full overflow-hidden bg-white h-full">
                          <img
                            src={profile.image}
                            alt={profile.name}
                            className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-110"
                          />
                          <div className="absolute inset-0 bg-black/10 group-hover:bg-black/30 transition-colors duration-300">
                            <div className="absolute inset-0 flex items-center justify-center">
                              <Play className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-75 group-hover:scale-100" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-center mt-1">
                        <h3 className="font-medium text-[11px] truncate max-w-[68px] mx-auto">{profile.name}</h3>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="hidden md:flex -left-12 bg-white/50 backdrop-blur-sm hover:bg-white/75" />
              <CarouselNext className="hidden md:flex -right-12 bg-white/50 backdrop-blur-sm hover:bg-white/75" />
            </Carousel>
          </div>

          {/* Categories */}
          <div className="flex gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={category.active ? "default" : "outline"}
                className={category.active ? "bg-[#1A1F2C]" : ""}
              >
                {category.name}
              </Button>
            ))}
          </div>

          {/* Quick Filters */}
          <div>
            <h2 className="text-lg font-medium mb-3">Filtros rápidos</h2>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {filters.map((filter, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="whitespace-nowrap"
                >
                  {filter}
                </Button>
              ))}
            </div>
          </div>

          {/* Profile Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regularProfiles.map((profile) => (
              <Card key={profile.id} className="overflow-hidden group cursor-pointer">
                <CardContent className="p-0">
                  <div className="relative">
                    <img
                      src={profile.image}
                      alt={profile.name}
                      className="w-full aspect-[3/4] object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="absolute bottom-4 left-4 text-white">
                        <h3 className="text-lg font-semibold">{profile.name}</h3>
                        <div className="flex items-center gap-1 text-sm">
                          <MapPin className="w-4 h-4" />
                          <span>{profile.location}</span>
                        </div>
                      </div>
                    </div>
                    {profile.hasReviews && (
                      <div className="absolute top-4 right-4 bg-red-500 text-white text-sm px-3 py-1 rounded-full">
                        Reviews Liberados
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
};

export default Escorts;
