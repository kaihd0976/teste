import { Header } from "@/components/Header";
import { SearchBar } from "@/components/SearchBar";
import { PopularLinks } from "@/components/PopularLinks";
import { BottomNav } from "@/components/BottomNav";

const Index = () => {
  const stats = [
    { number: "+20 milhões", label: "de usuários" },
    { number: "+50 mil", label: "acompanhantes" },
    { number: "+600 mil", label: "vídeos" },
    { number: "+70 mil", label: "reviews" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8 md:py-16">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="w-full md:w-1/2 space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold">
                <span className="text-primary">A maior plataforma</span> de
                <br />
                acompanhantes do Brasil
              </h1>
              
              <div className="space-y-2">
                {stats.map((stat) => (
                  <div key={stat.number} className="flex items-baseline gap-2">
                    <span className="text-xl font-bold text-textDark">
                      {stat.number}
                    </span>
                    <span className="text-gray-600">{stat.label}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <SearchBar />
            <PopularLinks />
          </div>
          
          <div className="w-full md:w-1/2 flex justify-center">
            <img
              src="/lovable-uploads/e5f23846-7632-40ac-9d6c-63b964d9d446.png"
              alt="lovable Love Model"
              className="max-w-full h-auto rounded-3xl"
            />
          </div>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
};

export default Index;