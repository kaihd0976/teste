import { Bell } from "lucide-react";
import { Link } from "react-router-dom";

export const Header = () => {
  return (
    <header className="w-full bg-white py-4 px-6 flex justify-between items-center shadow-sm">
      <Link to="/" className="flex items-center">
        <span className="text-2xl font-bold text-primary">lovable LOVE</span>
      </Link>
      
      <div className="flex items-center gap-4">
        <button className="text-primary hover:text-secondary transition-colors">
          CADASTRE-SE GRÁTIS
        </button>
        <button className="text-primary hover:text-secondary transition-colors">
          LOGIN
        </button>
        <div className="relative">
          <Bell className="w-6 h-6 text-primary" />
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
            3
          </span>
        </div>
      </div>
    </header>
  );
};