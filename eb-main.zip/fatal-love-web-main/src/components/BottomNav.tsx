import { UserPlus, Users, Video, MessageSquare } from "lucide-react";
import { Link } from "react-router-dom";

export const BottomNav = () => {
  const items = [
    { icon: UserPlus, text: "Cadastre Grátis", href: "/register" },
    { icon: Users, text: "Acompanhantes", href: "/escorts" },
    { icon: Video, text: "Vídeos", href: "/videos" },
    { icon: MessageSquare, text: "Reviews", href: "/reviews" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 py-2 px-4 md:hidden z-50">
      <div className="max-w-screen-xl mx-auto">
        <div className="grid grid-cols-4 gap-1">
          {items.map((item) => (
            <Link
              key={item.text}
              to={item.href}
              className="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              <item.icon className="w-6 h-6 text-primary mb-1" />
              <span className="text-xs font-medium text-textDark dark:text-gray-300 text-center">
                {item.text}
              </span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};