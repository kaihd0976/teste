import { MessageSquare, Video, Users, PhoneCall } from "lucide-react";
import { Link } from "react-router-dom";

export const PopularLinks = () => {
  const links = [
    { icon: MessageSquare, text: "Ler reviews", href: "/reviews" },
    { icon: Video, text: "Assistir vídeos", href: "/videos" },
    { icon: Users, text: "Ver acompanhantes", href: "/escorts" },
    { icon: PhoneCall, text: "Atendimento virtual", href: "/support" },
  ];

  return (
    <div className="w-full max-w-xl">
      <h3 className="text-lg font-semibold mb-4 text-textDark">Links populares</h3>
      <div className="space-y-2">
        {links.map((link) => (
          <Link
            key={link.text}
            to={link.href}
            className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors"
          >
            <link.icon className="w-5 h-5 text-primary" />
            <span className="text-textDark">{link.text}</span>
          </Link>
        ))}
      </div>
    </div>
  );
};